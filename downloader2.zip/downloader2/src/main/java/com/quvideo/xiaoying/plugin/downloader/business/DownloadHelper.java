package com.quvideo.xiaoying.plugin.downloader.business;

import android.content.Context;
import com.quvideo.xiaoying.plugin.downloader.dao.DBHelper;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadInfo;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadRecord;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadStatus;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadType;
import com.quvideo.xiaoying.plugin.downloader.entity.TemporaryRecord;
import com.quvideo.xiaoying.plugin.downloader.http.DownloadApi;
import com.quvideo.xiaoying.plugin.downloader.http.RetrofitProvider;
import com.quvideo.xiaoying.plugin.downloader.utils.FileUtils;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.ObservableSource;
import io.reactivex.disposables.Disposable;
import io.reactivex.exceptions.CompositeException;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import retrofit2.Response;
import retrofit2.Retrofit;

import static android.os.Environment.DIRECTORY_DOWNLOADS;
import static android.os.Environment.getExternalStoragePublicDirectory;
import static com.quvideo.xiaoying.plugin.downloader.constants.HttpConstants.ApiParam.TEST_RANGE_SUPPORT;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.DOWNLOAD_URL_EXISTS;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.REQUEST_RETRY_HINT;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.URL_ILLEGAL;
import static com.quvideo.xiaoying.plugin.downloader.utils.CharacterUtils.formatStr;
import static com.quvideo.xiaoying.plugin.downloader.utils.LogUtils.log;
import static com.quvideo.xiaoying.plugin.downloader.utils.RxUtils.retry;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public class DownloadHelper {
  private int maxRetryCount = 3;
  private int maxThreads = 3;

  private boolean isSupportRangeDownload = true;

  private String defaultSavePath;
  private DownloadApi downloadApi;

  private DBHelper dBHelper;
  private TemporaryRecordTable recordTable;

  public DownloadHelper(Context context) {
    downloadApi = RetrofitProvider.getInstance().create(DownloadApi.class);
    defaultSavePath = getExternalStoragePublicDirectory(DIRECTORY_DOWNLOADS).getPath();
    recordTable = new TemporaryRecordTable();
    dBHelper = DBHelper.getInstance(context.getApplicationContext());
  }

  public void setRetrofit(Retrofit retrofit) {
    downloadApi = retrofit.create(DownloadApi.class);
  }

  public void setDefaultSavePath(String defaultSavePath) {
    this.defaultSavePath = defaultSavePath;
  }

  public void setMaxRetryCount(int maxRetryCount) {
    this.maxRetryCount = maxRetryCount;
  }

  public void setMaxThreads(int maxThreads) {
    this.maxThreads = maxThreads;
  }

  /**
   * return Files
   *
   * @param url url
   * @return Files = {file,tempFile,lmfFile,dstFile}
   */
  public File[] getFiles(String url) {
    DownloadRecord record = dBHelper.readSingleRecord(url);
    if (record == null) {
      return null;
    } else {
      return FileUtils.getFiles(record.getSaveName(), record.getSavePath());
    }
  }

  /**
   * dispatch download
   *
   * @param bean download bean
   * @return DownloadStatus
   */
  public Observable<DownloadStatus> downloadDispatcher(final DownloadInfo bean) {
    return Observable.just(true).doOnSubscribe(new Consumer<Disposable>() {
      @Override public void accept(Disposable disposable) throws Exception {
        addTempRecord(bean);
      }
    }).flatMap(new Function<Boolean, ObservableSource<DownloadType>>() {
      @Override public ObservableSource<DownloadType> apply(Boolean aBoolean) throws Exception {
        return getDownloadType(bean.getUrl());
      }
    }).flatMap(new Function<DownloadType, ObservableSource<DownloadStatus>>() {
      @Override public ObservableSource<DownloadStatus> apply(DownloadType type) throws Exception {
        return download(type);
      }
    }).doOnError(new Consumer<Throwable>() {
      @Override public void accept(Throwable throwable) throws Exception {
        logError(throwable);
      }
    }).doFinally(new Action() {
      @Override public void run() throws Exception {
        recordTable.delete(bean.getUrl());
      }
    });
  }

  private ObservableSource<DownloadStatus> download(DownloadType downloadType)
      throws IOException, ParseException {
    downloadType.prepareDownload();
    return downloadType.startDownload();
  }

  private void logError(Throwable throwable) {
    if (throwable instanceof CompositeException) {
      CompositeException realException = (CompositeException) throwable;
      List<Throwable> exceptions = realException.getExceptions();
      for (Throwable each : exceptions) {
        log(each);
      }
    } else {
      log(throwable);
    }
  }

  /**
   * Add a temporary record to the record recordTable.
   *
   * @param bean download bean
   */
  private void addTempRecord(DownloadInfo bean) {
    if (recordTable.contain(bean.getUrl())) {
      throw new IllegalArgumentException(formatStr(DOWNLOAD_URL_EXISTS, bean.getUrl()));
    }
    recordTable.add(bean.getUrl(), new TemporaryRecord(bean));
  }

  /**
   * get download type.
   *
   * @param url url
   * @return download type
   */
  private Observable<DownloadType> getDownloadType(final String url) {
    return Observable.just(true).flatMap(new Function<Boolean, ObservableSource<Object>>() {
      @Override public ObservableSource<Object> apply(Boolean aBoolean) throws Exception {
        return checkUrl(url);
      }
    }).flatMap(new Function<Object, ObservableSource<Object>>() {
      @Override public ObservableSource<Object> apply(Object o) throws Exception {
        return checkRange(url);
      }
    }).doOnNext(new Consumer<Object>() {
      @Override public void accept(Object o) throws Exception {
        recordTable.init(url, maxThreads, maxRetryCount, defaultSavePath, downloadApi, dBHelper);
      }
    }).flatMap(new Function<Object, ObservableSource<DownloadType>>() {
      @Override public ObservableSource<DownloadType> apply(Object o) throws Exception {
        return recordTable.fileExists(url) ? existsType(url) : nonExistsType(url);
      }
    });
  }

  /**
   * Gets the download type of file non-existence.
   *
   * @param url file url
   * @return Download Type
   */
  private Observable<DownloadType> nonExistsType(final String url) {
    return Observable.just(true).flatMap(new Function<Boolean, ObservableSource<DownloadType>>() {
      @Override public ObservableSource<DownloadType> apply(Boolean aBoolean) throws Exception {
        return Observable.just(recordTable.generateNonExistsType(url));
      }
    });
  }

  /**
   * Gets the download type of file existence.
   *
   * @param url file url
   * @return Download Type
   */
  private Observable<DownloadType> existsType(final String url) {
    return Observable.just(true).map(new Function<Boolean, String>() {
      @Override public String apply(Boolean aBoolean) throws Exception {
        return recordTable.readLastModify(url);
      }
    }).flatMap(new Function<String, ObservableSource<Object>>() {
      @Override public ObservableSource<Object> apply(String s) throws Exception {
        TemporaryRecord record = recordTable.get(url);
        return record != null && record.checkFileModify() ? checkFile(url, s) : doNotCheckFile(url);
      }
    }).flatMap(new Function<Object, ObservableSource<DownloadType>>() {
      @Override public ObservableSource<DownloadType> apply(Object o) throws Exception {
        return Observable.just(recordTable.generateFileExistsType(url));
      }
    });
  }

  private static final String HEADER_FILE_SIZE = "Content-Length";

  /**
   * 获取指定 下载文件的大小
   *
   * @param url 下载文件地址
   * @return 文件大小
   */
  public Observable<Long> getDownloadFileSize(final String url) {
    return downloadApi.check(url)
        .subscribeOn(Schedulers.io())
        .flatMap(new Function<Response<Void>, ObservableSource<Long>>() {
          @Override public ObservableSource<Long> apply(Response<Void> voidResponse)
              throws Exception {
            if (voidResponse == null || !voidResponse.isSuccessful()) {
              return getDownloadFileSizeByGet(url).subscribeOn(Schedulers.io());
            }
            return Observable.just(Long.parseLong(voidResponse.headers().get(HEADER_FILE_SIZE)))
                .subscribeOn(Schedulers.io());
          }
        });
  }

  private Observable<Long> getDownloadFileSizeByGet(final String url) {
    return downloadApi.checkByGet(url).map(new Function<Response<Void>, Long>() {
      @Override public Long apply(Response<Void> voidResponse) throws Exception {
        if (voidResponse != null && voidResponse.isSuccessful()) {
          return Long.parseLong(voidResponse.headers().get(HEADER_FILE_SIZE));
        }
        throw new IllegalArgumentException(formatStr(URL_ILLEGAL, url));
      }
    });
  }

  /**
   * check url
   *
   * @param url url
   * @return empty
   */
  private ObservableSource<Object> checkUrl(final String url) {
    return downloadApi.check(url).flatMap(new Function<Response<Void>, ObservableSource<Object>>() {
      @Override public ObservableSource<Object> apply(Response<Void> resp) throws Exception {
        if (!resp.isSuccessful()) {
          return checkUrlByGet(url);
        } else {
          return saveFileInfo(url, resp);
        }
      }
    }).compose(retry(REQUEST_RETRY_HINT, maxRetryCount));
  }

  private ObservableSource<Object> saveFileInfo(final String url, final Response<Void> resp) {
    return Observable.create(new ObservableOnSubscribe<Object>() {
      @Override public void subscribe(ObservableEmitter<Object> emitter) throws Exception {
        recordTable.saveFileInfo(url, resp);
        emitter.onNext(new Object());
        emitter.onComplete();
      }
    });
  }

  private ObservableSource<Object> checkUrlByGet(final String url) {
    return downloadApi.checkByGet(url).doOnNext(new Consumer<Response<Void>>() {
      @Override public void accept(Response<Void> response) throws Exception {
        if (!response.isSuccessful()) {
          throw new IllegalArgumentException(formatStr(URL_ILLEGAL, url));
        } else {
          recordTable.saveFileInfo(url, response);
        }
      }
    }).map(new Function<Response<Void>, Object>() {
      @Override public Object apply(Response<Void> response) throws Exception {
        return new Object();
      }
    }).compose(retry(REQUEST_RETRY_HINT, maxRetryCount));
  }

  /**
   * http checkRangeByHead request,checkRange need info.
   *
   * @param url url
   * @return empty Observable
   */
  private ObservableSource<Object> checkRange(final String url) {
    return downloadApi.checkRangeByHead(TEST_RANGE_SUPPORT, url)
        .doOnNext(new Consumer<Response<Void>>() {
          @Override public void accept(Response<Void> response) throws Exception {
            recordTable.saveRangeInfo(url, response, isSupportRangeDownload);
          }
        })
        .map(new Function<Response<Void>, Object>() {
          @Override public Object apply(Response<Void> response) throws Exception {
            return new Object();
          }
        })
        .compose(retry(REQUEST_RETRY_HINT, maxRetryCount));
  }

  /**
   * http checkRangeByHead request,checkRange need info, check whether if server file has changed.
   *
   * @param url url
   * @return empty Observable
   */
  private ObservableSource<Object> checkFile(final String url, String lastModify) {
    return downloadApi.checkFileByHead(lastModify, url).doOnNext(new Consumer<Response<Void>>() {
      @Override public void accept(Response<Void> response) throws Exception {
        recordTable.saveFileState(url, response);
      }
    }).map(new Function<Response<Void>, Object>() {
      @Override public Object apply(Response<Void> response) throws Exception {
        return new Object();
      }
    }).compose(retry(REQUEST_RETRY_HINT, maxRetryCount));
  }

  /**
   * don't check file modify state
   *
   * @param url url
   * @return empty Observable
   */
  public ObservableSource<Object> doNotCheckFile(final String url) {
    return Observable.just(new Object()).doOnNext(new Consumer<Object>() {
      @Override public void accept(Object s) throws Exception {
        recordTable.forceFlagFileState(url, false);
      }
    });
  }

  public Observable<List<DownloadRecord>> readAllRecords() {
    return dBHelper.readAllRecords();
  }

  public Observable<DownloadRecord> readRecord(String url) {
    return dBHelper.readRecord(url);
  }

  public void setSupportRangeDownload(boolean support) {
    this.isSupportRangeDownload = support;
  }
}
