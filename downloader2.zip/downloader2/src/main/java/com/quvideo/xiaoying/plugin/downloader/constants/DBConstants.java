package com.quvideo.xiaoying.plugin.downloader.constants;

/**
 * Created by Administrator on 2017/10/16.
 *
 * @author luc
 */

public class DBConstants {

  public static final class RecordTable {
    public static final String TABLE_NAME = "download_record";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_URL = "url";
    public static final String COLUMN_SAVE_NAME = "save_name";
    public static final String COLUMN_SAVE_PATH = "save_path";
    public static final String COLUMN_DOWNLOAD_SIZE = "download_size";
    public static final String COLUMN_TOTAL_SIZE = "total_size";
    public static final String COLUMN_IS_CHUNKED = "is_chunked";
    public static final String COLUMN_DOWNLOAD_FLAG = "download_flag";
    public static final String COLUMN_DATE = "date";

    public static final String SQL_CREATE = "CREATE TABLE "
        + TABLE_NAME
        + " ("
        + COLUMN_ID
        + " INTEGER PRIMARY KEY AUTOINCREMENT,"
        + COLUMN_URL
        + " TEXT NOT NULL,"
        + COLUMN_SAVE_NAME
        + " TEXT,"
        + COLUMN_SAVE_PATH
        + " TEXT,"
        + COLUMN_TOTAL_SIZE
        + " INTEGER,"
        + COLUMN_DOWNLOAD_SIZE
        + " INTEGER,"
        + COLUMN_IS_CHUNKED
        + " INTEGER,"
        + COLUMN_DOWNLOAD_FLAG
        + " INTEGER,"
        + COLUMN_DATE
        + " INTEGER NOT NULL "
        + " )";
  }
}
