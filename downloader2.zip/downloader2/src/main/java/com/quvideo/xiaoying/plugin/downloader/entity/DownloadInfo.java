package com.quvideo.xiaoying.plugin.downloader.entity;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public class DownloadInfo {
  private String url;
  private String saveName;
  private String savePath;
  private boolean checkFileModify = true;

  public DownloadInfo() {
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getSaveName() {
    return saveName;
  }

  public void setSaveName(String saveName) {
    this.saveName = saveName;
  }

  public String getSavePath() {
    return savePath;
  }

  public void setSavePath(String savePath) {
    this.savePath = savePath;
  }

  public boolean isCheckFileModify() {
    return checkFileModify;
  }

  public void setCheckFileModify(boolean checkFileModify) {
    this.checkFileModify = checkFileModify;
  }

  public static class Builder {
    private String url;
    private String saveName;
    private String savePath;
    private boolean checkFileModify = true;

    public Builder(String url) {
      this.url = url;
    }

    public Builder setSaveName(String saveName) {
      this.saveName = saveName;
      return this;
    }

    public Builder setSavePath(String savePath) {
      this.savePath = savePath;
      return this;
    }

    public Builder setCheckFileModify(boolean checkFileModify) {
      this.checkFileModify = checkFileModify;
      return this;
    }

    public DownloadInfo build() {
      DownloadInfo bean = new DownloadInfo();
      bean.url = this.url;
      bean.saveName = this.saveName;
      bean.savePath = this.savePath;
      bean.checkFileModify = this.checkFileModify;
      return bean;
    }
  }
}
