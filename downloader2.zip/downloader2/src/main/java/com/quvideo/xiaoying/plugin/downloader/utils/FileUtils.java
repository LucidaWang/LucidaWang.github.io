package com.quvideo.xiaoying.plugin.downloader.utils;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;

import static android.text.TextUtils.concat;
import static com.quvideo.xiaoying.plugin.downloader.constants.FileConstants.CACHE;
import static com.quvideo.xiaoying.plugin.downloader.constants.FileConstants.DOWNLOAD_SHORT_SUFFIX;
import static com.quvideo.xiaoying.plugin.downloader.constants.FileConstants.LMF_SUFFIX;
import static com.quvideo.xiaoying.plugin.downloader.constants.FileConstants.TMP_SUFFIX;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.DIR_CREATE_FAILED;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.DIR_CREATE_SUCCESS;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.DIR_EXISTS_HINT;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.DIR_NOT_EXISTS_HINT;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.FILE_DELETE_FAILED;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.FILE_DELETE_SUCCESS;
import static com.quvideo.xiaoying.plugin.downloader.utils.LogUtils.log;
import static java.io.File.separator;
import static java.lang.String.format;
import static java.util.Locale.getDefault;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */

public class FileUtils {
  public static void closeQuietly(Closeable closeable) {
    if (closeable != null) {
      try {
        closeable.close();
      } catch (RuntimeException rethrown) {
        throw rethrown;
      } catch (Exception ignored) {
      }
    }
  }

  /**
   * Format file size to String
   *
   * @param size long
   * @return String
   */
  public static String formatSize(long size) {
    String hrSize;
    double b = size;
    double k = size / 1024.0;
    double m = ((size / 1024.0) / 1024.0);
    double g = (((size / 1024.0) / 1024.0) / 1024.0);
    double t = ((((size / 1024.0) / 1024.0) / 1024.0) / 1024.0);
    DecimalFormat dec = new DecimalFormat("0.00");
    if (t > 1) {
      hrSize = dec.format(t).concat(" TB");
    } else if (g > 1) {
      hrSize = dec.format(g).concat(" GB");
    } else if (m > 1) {
      hrSize = dec.format(m).concat(" MB");
    } else if (k > 1) {
      hrSize = dec.format(k).concat(" KB");
    } else {
      hrSize = dec.format(b).concat(" B");
    }
    return hrSize;
  }

  /**
   * return file paths
   *
   * @param saveName saveName
   * @param savePath savePath
   * @return filePath, tempPath, lmfPath, dstPath
   */
  public static String[] getPaths(String saveName, String savePath) {
    String cachePath = concat(savePath, separator, CACHE).toString();
    String filePath = concat(savePath, separator, saveName).toString();
    String tempPath = concat(cachePath, separator, saveName, TMP_SUFFIX).toString();
    String lmfPath = concat(cachePath, separator, saveName, LMF_SUFFIX).toString();
    String dstPath = concat(savePath, separator, saveName, DOWNLOAD_SHORT_SUFFIX).toString();
    return new String[] { filePath, tempPath, lmfPath, dstPath };
  }

  /**
   * return files
   *
   * @param saveName saveName
   * @param savePath savePath
   * @return file, tempFile, lmfFile, dstFile
   */
  public static File[] getFiles(String saveName, String savePath) {
    String[] paths = getPaths(saveName, savePath);
    return new File[] {
        new File(paths[0]), new File(paths[1]), new File(paths[2]), new File(paths[3])
    };
  }

  public static File[] getCacheFile(String saveName, String savePath) {
    String[] paths = getPaths(saveName, savePath);
    return new File[] { new File(paths[1]), new File(paths[2]) };
  }

  public static File getDownloadFile(File[] files) {
    return files != null && files.length > 0 ? files[0] : null;
  }

  /**
   * create dirs with params path
   *
   * @param paths paths
   */
  public static void mkdirs(String... paths) {
    for (String each : paths) {
      File file = new File(each);
      if (file.exists() && file.isDirectory()) {
        log(DIR_EXISTS_HINT, each);
      } else {
        log(DIR_NOT_EXISTS_HINT, each);
        boolean flag = file.mkdirs();
        if (flag) {
          log(DIR_CREATE_SUCCESS, each);
        } else {
          log(DIR_CREATE_FAILED, each);
        }
      }
    }
  }

  /**
   * delete files
   *
   * @param files files
   */
  public static void deleteFiles(File... files) {
    for (File each : files) {
      if (each.exists()) {
        boolean flag = each.delete();
        if (flag) {
          log(format(getDefault(), FILE_DELETE_SUCCESS, each.getName()));
        } else {
          log(format(getDefault(), FILE_DELETE_FAILED, each.getName()));
        }
      }
    }
  }

  public static void close(Closeable closeable) throws IOException {
    if (closeable != null) {
      closeable.close();
    }
  }
}
