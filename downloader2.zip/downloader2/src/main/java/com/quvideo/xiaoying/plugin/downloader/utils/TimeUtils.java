package com.quvideo.xiaoying.plugin.downloader.utils;

import android.text.TextUtils;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static java.util.TimeZone.getTimeZone;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */

public class TimeUtils {
  /**
   * convert long to GMT string
   *
   * @param lastModify long
   * @return String
   */
  public static String longToGMT(long lastModify) {
    Date d = new Date(lastModify);
    SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
    sdf.setTimeZone(getTimeZone("GMT"));
    return sdf.format(d);
  }

  /**
   * convert GMT string to long
   *
   * @param GMT String
   * @return long
   * @throws ParseException
   */
  public static long GMTToLong(String GMT) throws ParseException {
    if (TextUtils.isEmpty(GMT)) {
      return new Date().getTime();
    }
    SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
    sdf.setTimeZone(getTimeZone("GMT"));
    Date date = sdf.parse(GMT);
    return date.getTime();
  }
}
