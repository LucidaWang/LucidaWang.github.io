package com.quvideo.xiaoying.plugin.downloader.constants;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public class DownloadConstants {
  public static final class Flag {
    public static final int NORMAL = 9990;      //未下载
    public static final int WAITING = 9991;     //等待中
    public static final int STARTED = 9992;     //已开始下载
    public static final int PAUSED = 9993;      //已暂停
    public static final int COMPLETED = 9994;   //已完成
    public static final int FAILED = 9995;      //下载失败
  }

  public static final class IntentKey {
    public static final String MAX_DOWNLOAD_NUMBER = "quvideo_xiaoying_max_download_number";
  }

  public static final class IntentDefaultValue {
    public static final int MAX_DOWNLOAD_NUMBER = 5;
  }
}
