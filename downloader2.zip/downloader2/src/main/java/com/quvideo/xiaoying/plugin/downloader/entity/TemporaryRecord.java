package com.quvideo.xiaoying.plugin.downloader.entity;

import android.text.TextUtils;
import com.quvideo.xiaoying.plugin.downloader.dao.DBHelper;
import com.quvideo.xiaoying.plugin.downloader.http.DownloadApi;
import com.quvideo.xiaoying.plugin.downloader.utils.FileHelper;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.functions.Function;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import okhttp3.ResponseBody;
import org.reactivestreams.Publisher;
import retrofit2.Response;

import static android.text.TextUtils.concat;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.COMPLETED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.FAILED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.PAUSED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.STARTED;
import static com.quvideo.xiaoying.plugin.downloader.constants.FileConstants.CACHE;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.RANGE_DOWNLOAD_STARTED;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.getPaths;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.mkdirs;
import static com.quvideo.xiaoying.plugin.downloader.utils.LogUtils.log;
import static java.io.File.separator;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public class TemporaryRecord {
  private DownloadInfo bean;

  private String filePath;
  private String dstPath;
  private String tempPath;
  private String lmfPath;

  private int maxRetryCount;
  private int maxThreads;

  private long contentLength;
  private String lastModify;

  private boolean rangeSupport = false;
  private boolean serverFileChanged = false;

  private DBHelper dBHelper;
  private FileHelper fileHelper;
  private DownloadApi downloadApi;

  public TemporaryRecord(DownloadInfo bean) {
    this.bean = bean;
  }

  /**
   * init needs info
   *
   * @param maxThreads Max download threads
   * @param maxRetryCount Max retry times
   * @param defaultSavePath Default save path;
   * @param downloadApi API
   * @param dBHelper DataBaseHelper
   */
  public void init(int maxThreads, int maxRetryCount, String defaultSavePath,
      DownloadApi downloadApi, DBHelper dBHelper) {
    this.maxThreads = maxThreads;
    this.maxRetryCount = maxRetryCount;
    this.downloadApi = downloadApi;
    this.dBHelper = dBHelper;
    this.fileHelper = new FileHelper(maxThreads);

    String realSavePath;
    if (TextUtils.isEmpty(bean.getSavePath())) {
      realSavePath = defaultSavePath;
      bean.setSavePath(defaultSavePath);
    } else {
      realSavePath = bean.getSavePath();
    }
    String cachePath = concat(realSavePath, separator, CACHE).toString();
    mkdirs(realSavePath, cachePath);

    String[] paths = getPaths(bean.getSaveName(), realSavePath);
    filePath = paths[0];
    tempPath = paths[1];
    lmfPath = paths[2];
    dstPath = paths[3];
  }

  /**
   * prepare normal download, create files and save last-modify.
   *
   * @throws IOException
   * @throws ParseException
   */
  public void prepareNormalDownload() throws IOException, ParseException {
    fileHelper.prepareDownload(lastModifyFile(), dstFile(), contentLength, lastModify);
  }

  /**
   * prepare range download, create necessary files and save last-modify.
   *
   * @throws IOException
   * @throws ParseException
   */
  public void prepareRangeDownload() throws IOException, ParseException {
    fileHelper.prepareDownload(lastModifyFile(), tempFile(), dstFile(), contentLength, lastModify);
  }

  /**
   * Read download range from record file.
   *
   * @param index index
   * @throws IOException
   */
  public DownloadRange readDownloadRange(int index) throws IOException {
    return fileHelper.readDownloadRange(tempFile(), index);
  }

  /**
   * Normal download save.
   *
   * @param e emitter
   * @param response response
   */
  public void save(FlowableEmitter<DownloadStatus> e, Response<ResponseBody> response) {
    fileHelper.saveFile(e, dstFile(), file(), response);
  }

  /**
   * Range download save
   *
   * @param emitter emitter
   * @param index download index
   * @param response response
   * @throws IOException
   */
  public void save(FlowableEmitter<DownloadStatus> emitter, int index, ResponseBody response)
      throws IOException {
    fileHelper.saveFile(emitter, index, tempFile(), dstFile(), file(), response);
  }

  /**
   * Normal download request.
   *
   * @return response
   */
  public Flowable<Response<ResponseBody>> download() {
    return downloadApi.download(null, bean.getUrl());
  }

  /**
   * Range download request
   *
   * @param index download index
   * @return response
   */
  public Flowable<Response<ResponseBody>> rangeDownload(final int index) {
    return Flowable.create(new FlowableOnSubscribe<DownloadRange>() {
      @Override public void subscribe(FlowableEmitter<DownloadRange> e) throws Exception {
        DownloadRange range = readDownloadRange(index);
        if (range.legal()) {
          e.onNext(range);
        }
        e.onComplete();
      }
    }, BackpressureStrategy.ERROR)
        .flatMap(new Function<DownloadRange, Publisher<Response<ResponseBody>>>() {
          @Override public Publisher<Response<ResponseBody>> apply(DownloadRange range)
              throws Exception {
            log("Thread: " + Thread.currentThread().getName() + "; " + RANGE_DOWNLOAD_STARTED,
                index, range.start, range.end);
            String rangeStr = "bytes=" + range.start + "-" + range.end;
            return downloadApi.download(rangeStr, bean.getUrl());
          }
        });
  }

  public int getMaxRetryCount() {
    return maxRetryCount;
  }

  public int getMaxThreads() {
    return maxThreads;
  }

  public boolean isSupportRange() {
    return rangeSupport;
  }

  public void setRangeSupport(boolean rangeSupport) {
    this.rangeSupport = rangeSupport;
  }

  public boolean isFileChanged() {
    return serverFileChanged;
  }

  public void setFileChanged(boolean serverFileChanged) {
    this.serverFileChanged = serverFileChanged;
  }

  public long getContentLength() {
    return contentLength;
  }

  public void setContentLength(long contentLength) {
    this.contentLength = contentLength;
  }

  public void setLastModify(String lastModify) {
    this.lastModify = lastModify;
  }

  public String getSaveName() {
    return bean.getSaveName();
  }

  public void setSaveName(String saveName) {
    bean.setSaveName(saveName);
  }

  public File file() {
    return new File(filePath);
  }

  public File tempFile() {
    return new File(tempPath);
  }

  public File lastModifyFile() {
    return new File(lmfPath);
  }

  public File dstFile() {
    return new File(dstPath);
  }

  public boolean fileComplete() {
    return dstFile().length() == contentLength || file().exists();
  }

  public boolean tempFileDamaged() throws IOException {
    return fileHelper.tempFileDamaged(tempFile(), contentLength);
  }

  public String readLastModify() throws IOException {
    return fileHelper.readLastModify(lastModifyFile());
  }

  public boolean fileNotComplete() throws IOException {
    return fileHelper.fileNotComplete(tempFile());
  }

  public File[] getFiles() {
    return new File[] { file(), tempFile(), lastModifyFile() };
  }

  public void start() {
    if (dBHelper.recordNotExists(bean.getUrl())) {
      dBHelper.insertRecord(bean, STARTED);
    } else {
      dBHelper.updateRecord(bean.getUrl(), bean.getSaveName(), bean.getSavePath(), STARTED);
    }
  }

  public void update(DownloadStatus status) {
    dBHelper.updateStatus(bean.getUrl(), status);
  }

  public void error() {
    dBHelper.updateRecord(bean.getUrl(), FAILED);
  }

  public void complete() {
    dBHelper.updateRecord(bean.getUrl(), COMPLETED);
  }

  public void cancel() {
    dBHelper.updateRecord(bean.getUrl(), PAUSED);
  }

  public void finish() {
  }

  public boolean checkFileModify() {
    return bean == null || bean.isCheckFileModify();
  }
}
