package com.quvideo.xiaoying.plugin.downloader.entity;

import com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public class DownloadEvent {
  private int flag = DownloadConstants.Flag.NORMAL;
  private String url;
  private String name;
  private String path;
  private DownloadStatus downloadStatus = new DownloadStatus();
  private Throwable mError;

  public int getFlag() {
    return flag;
  }

  public void setFlag(int flag) {
    this.flag = flag;
  }

  public DownloadStatus getDownloadStatus() {
    return downloadStatus;
  }

  public void setDownloadStatus(DownloadStatus downloadStatus) {
    this.downloadStatus = downloadStatus;
  }

  public Throwable getError() {
    return mError;
  }

  public void setError(Throwable error) {
    mError = error;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }
}
