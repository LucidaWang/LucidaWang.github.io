package com.quvideo.xiaoying.plugin.downloader.business;

import android.text.TextUtils;
import com.quvideo.xiaoying.plugin.downloader.dao.DBHelper;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadType;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadType.AlreadyDownloaded;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadType.ContinueDownload;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadType.MultiThreadDownload;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadType.NormalDownload;
import com.quvideo.xiaoying.plugin.downloader.entity.TemporaryRecord;
import com.quvideo.xiaoying.plugin.downloader.http.DownloadApi;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import retrofit2.Response;

import static com.quvideo.xiaoying.plugin.downloader.constants.HttpConstants.ResponseCode._200;
import static com.quvideo.xiaoying.plugin.downloader.constants.HttpConstants.ResponseCode._304;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.DOWNLOAD_RECORD_FILE_DAMAGED;
import static com.quvideo.xiaoying.plugin.downloader.utils.HttpUtils.contentLength;
import static com.quvideo.xiaoying.plugin.downloader.utils.HttpUtils.fileName;
import static com.quvideo.xiaoying.plugin.downloader.utils.HttpUtils.lastModify;
import static com.quvideo.xiaoying.plugin.downloader.utils.HttpUtils.notSupportRange;
import static com.quvideo.xiaoying.plugin.downloader.utils.LogUtils.log;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public class TemporaryRecordTable {
  private Map<String, TemporaryRecord> map;

  public TemporaryRecordTable() {
    this.map = new HashMap<>();
  }

  public void add(String url, TemporaryRecord record) {
    map.put(url, record);
  }

  public boolean contain(String url) {
    return map.get(url) != null;
  }

  public void delete(String url) {
    map.remove(url);
  }

  public TemporaryRecord get(String url) {
    return map.get(url);
  }

  /**
   * Save file info
   *
   * @param url key
   * @param response response
   */
  public void saveFileInfo(String url, Response<?> response) {
    TemporaryRecord record = map.get(url);
    if (TextUtils.isEmpty(record.getSaveName())) {
      record.setSaveName(fileName(url, response));
    }
    record.setContentLength(contentLength(response));
    record.setLastModify(lastModify(response));
  }

  /**
   * Save range info
   *
   * @param url key
   * @param response response
   * @param supportRangeDownload supportRangeDownload
   */
  public void saveRangeInfo(String url, Response<?> response, boolean supportRangeDownload) {
    map.get(url).setRangeSupport(supportRangeDownload && !notSupportRange(response));
  }

  /**
   * Init necessary info
   *
   * @param url url
   * @param maxThreads max threads
   * @param maxRetryCount retry count
   * @param defaultSavePath default save path
   * @param downloadApi api
   * @param dBHelper DataBaseHelper
   */
  public void init(String url, int maxThreads, int maxRetryCount, String defaultSavePath,
      DownloadApi downloadApi, DBHelper dBHelper) {
    map.get(url).init(maxThreads, maxRetryCount, defaultSavePath, downloadApi, dBHelper);
  }

  /**
   * Save file state, change or not change.
   *
   * @param url key
   * @param response response
   */
  public void saveFileState(String url, Response<Void> response) {
    if (response.code() == _304) {
      map.get(url).setFileChanged(false);
    } else if (response.code() == _200) {
      map.get(url).setFileChanged(true);
    }
  }

  /**
   * flag file state，ignore check file modify
   */
  public void forceFlagFileState(String url, boolean state) {
    map.get(url).setFileChanged(state);
  }

  /**
   * return file not exists download type.
   *
   * @param url key
   * @return download type
   */
  public DownloadType generateNonExistsType(String url) {
    return getNormalType(url);
  }

  /**
   * return file exists download type
   *
   * @param url key
   * @return download type
   */
  public DownloadType generateFileExistsType(String url) {
    DownloadType type;
    if (fileChanged(url)) {
      type = getNormalType(url);
    } else {
      type = getServerFileChangeType(url);
    }
    return type;
  }

  /**
   * read last modify string
   *
   * @param url key
   * @return last modify
   */
  public String readLastModify(String url) {
    try {
      return map.get(url).readLastModify();
    } catch (IOException e) {
      //If read failed,return an empty string.
      //If we send empty last-modify,server will response 200.
      //That means file changed.
      return "";
    }
  }

  public boolean fileExists(String url) {
    return map.get(url).dstFile().exists();
  }

  public File[] getFiles(String url) {
    return map.get(url).getFiles();
  }

  private boolean supportRange(String url) {
    return map.get(url).isSupportRange();
  }

  private boolean fileChanged(String url) {
    return map.get(url).isFileChanged();
  }

  private DownloadType getNormalType(String url) {
    DownloadType type;
    if (supportRange(url)) {
      type = new MultiThreadDownload(map.get(url));
    } else {
      type = new NormalDownload(map.get(url));
    }
    return type;
  }

  private DownloadType getServerFileChangeType(String url) {
    if (supportRange(url)) {
      return supportRangeType(url);
    } else {
      return notSupportRangeType(url);
    }
  }

  private DownloadType supportRangeType(String url) {
    if (needReDownload(url)) {
      return new MultiThreadDownload(map.get(url));
    }
    try {
      if (multiDownloadNotComplete(url)) {
        return new ContinueDownload(map.get(url));
      }
    } catch (IOException e) {
      return new MultiThreadDownload(map.get(url));
    }
    return new AlreadyDownloaded(map.get(url));
  }

  private DownloadType notSupportRangeType(String url) {
    if (normalDownloadNotComplete(url)) {
      return new NormalDownload(map.get(url));
    } else {
      return new AlreadyDownloaded(map.get(url));
    }
  }

  private boolean multiDownloadNotComplete(String url) throws IOException {
    return map.get(url).fileNotComplete();
  }

  private boolean normalDownloadNotComplete(String url) {
    return !map.get(url).fileComplete();
  }

  private boolean needReDownload(String url) {
    return tempFileNotExists(url) || tempFileDamaged(url);
  }

  private boolean tempFileDamaged(String url) {
    try {
      return map.get(url).tempFileDamaged();
    } catch (IOException e) {
      log(DOWNLOAD_RECORD_FILE_DAMAGED);
      return true;
    }
  }

  private boolean tempFileNotExists(String url) {
    return !map.get(url).tempFile().exists();
  }
}
