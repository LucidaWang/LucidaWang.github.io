package com.quvideo.xiaoying.plugin.downloader.dao;

import android.content.ContentValues;
import android.database.Cursor;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadInfo;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadRecord;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadStatus;
import java.util.Date;

import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_DATE;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_DOWNLOAD_FLAG;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_DOWNLOAD_SIZE;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_ID;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_IS_CHUNKED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_SAVE_NAME;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_SAVE_PATH;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_TOTAL_SIZE;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_URL;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
class DBOptions {
  private DBOptions() {
  }

  static ContentValues insert(DownloadInfo bean, int flag) {
    ContentValues values = new ContentValues();
    values.put(COLUMN_URL, bean.getUrl());
    values.put(COLUMN_SAVE_NAME, bean.getSaveName());
    values.put(COLUMN_SAVE_PATH, bean.getSavePath());
    values.put(COLUMN_DOWNLOAD_FLAG, flag);
    values.put(COLUMN_DATE, new Date().getTime());
    return values;
  }

  static ContentValues update(DownloadStatus status) {
    ContentValues values = new ContentValues();
    values.put(COLUMN_IS_CHUNKED, status.isChunked);
    values.put(COLUMN_DOWNLOAD_SIZE, status.getDownloadSize());
    values.put(COLUMN_TOTAL_SIZE, status.getTotalSize());
    return values;
  }

  static ContentValues update(int flag) {
    ContentValues values = new ContentValues();
    values.put(COLUMN_DOWNLOAD_FLAG, flag);
    return values;
  }

  static ContentValues update(String saveName, String savePath, int flag) {
    ContentValues values = new ContentValues();
    values.put(COLUMN_SAVE_NAME, saveName);
    values.put(COLUMN_SAVE_PATH, savePath);
    values.put(COLUMN_DOWNLOAD_FLAG, flag);
    return values;
  }

  static DownloadStatus readStatus(Cursor cursor) {
    boolean isChunked = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_IS_CHUNKED)) > 0;
    long downloadSize = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_DOWNLOAD_SIZE));
    long totalSize = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_TOTAL_SIZE));
    return new DownloadStatus(isChunked, downloadSize, totalSize);
  }

  static DownloadRecord read(Cursor cursor) {
    DownloadRecord record = new DownloadRecord();
    record.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
    record.setUrl(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_URL)));
    record.setSaveName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SAVE_NAME)));
    record.setSavePath(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SAVE_PATH)));

    boolean isChunked = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_IS_CHUNKED)) > 0;
    long downloadSize = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_DOWNLOAD_SIZE));
    long totalSize = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_TOTAL_SIZE));
    record.setStatus(new DownloadStatus(isChunked, downloadSize, totalSize));

    record.setFlag(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_DOWNLOAD_FLAG)));
    record.setDate(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_DATE)));
    return record;
  }
}
