package com.quvideo.xiaoying.plugin.downloader.entity;

import com.quvideo.xiaoying.plugin.downloader.business.DownloadHelper;
import com.quvideo.xiaoying.plugin.downloader.business.DownloadService;
import com.quvideo.xiaoying.plugin.downloader.dao.DBHelper;
import io.reactivex.processors.FlowableProcessor;
import java.util.Map;
import java.util.concurrent.Semaphore;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public abstract class DownloadMission {
  protected DownloadHelper downloadHelper;
  protected DownloadService downloadService;
  FlowableProcessor<DownloadEvent> processor;
  private boolean canceled = false;
  private boolean completed = false;

  DownloadMission(DownloadService downloadService, DownloadHelper downloadHelper) {
    this.downloadService = downloadService;
    this.downloadHelper = downloadHelper;
  }

  public boolean isCanceled() {
    return canceled;
  }

  public void setCanceled(boolean canceled) {
    this.canceled = canceled;
  }

  public boolean isCompleted() {
    return completed;
  }

  public void setCompleted(boolean completed) {
    this.completed = completed;
  }

  public abstract String getUrl();

  public abstract void init(Map<String, DownloadMission> missionMap,
      Map<String, FlowableProcessor<DownloadEvent>> processorMap);

  public abstract void insertOrUpdate(DBHelper dBHelper);

  public abstract void start(final Semaphore semaphore) throws InterruptedException;

  public abstract void pause(DBHelper dBHelper);

  public abstract void delete(DBHelper dBHelper, boolean deleteFile);

  public abstract void sendWaitingEvent(DBHelper dBHelper);
}
