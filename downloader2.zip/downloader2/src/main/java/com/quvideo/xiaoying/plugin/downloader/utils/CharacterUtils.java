package com.quvideo.xiaoying.plugin.downloader.utils;

import static java.lang.String.format;
import static java.util.Locale.getDefault;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */

public class CharacterUtils {
  public static String formatStr(String str, Object... args) {
    return format(getDefault(), str, args);
  }
}
