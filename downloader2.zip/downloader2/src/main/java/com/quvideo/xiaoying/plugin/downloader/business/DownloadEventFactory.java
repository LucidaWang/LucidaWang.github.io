package com.quvideo.xiaoying.plugin.downloader.business;

import com.quvideo.xiaoying.plugin.downloader.entity.DownloadEvent;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadStatus;

import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.COMPLETED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.FAILED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.NORMAL;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.PAUSED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.STARTED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.WAITING;

/**
 * Created by Administrator on 2017/10/10.
 *
 * @author luc
 */
public class DownloadEventFactory {
  public static DownloadEvent normal(String url, DownloadStatus status) {
    return createEvent(NORMAL, url, status);
  }

  public static DownloadEvent waiting(String url, DownloadStatus status) {
    return createEvent(WAITING, url, status);
  }

  public static DownloadEvent started(String url, DownloadStatus status) {
    return createEvent(STARTED, url, status);
  }

  public static DownloadEvent paused(String url, DownloadStatus status) {
    return createEvent(PAUSED, url, status);
  }

  public static DownloadEvent completed(String url, String saveName, String savePath,
      DownloadStatus status) {
    return createEvent(COMPLETED, url, saveName, savePath, status);
  }

  public static DownloadEvent failed(String url, DownloadStatus status, Throwable throwable) {
    return createEvent(FAILED, url, status, throwable);
  }

  private static DownloadEvent createEvent(int flag, String url, DownloadStatus status,
      Throwable throwable) {
    DownloadEvent event = createEvent(flag, url, status);
    event.setError(throwable);
    return event;
  }

  public static DownloadEvent createEvent(int flag, String url, DownloadStatus status) {
    return createEvent(flag, url, null, null, status);
  }

  public static DownloadEvent createEvent(int flag, String url, String saveName, String savePath,
      DownloadStatus status) {
    DownloadEvent event = new DownloadEvent();
    event.setDownloadStatus(status == null ? new DownloadStatus() : status);
    event.setName(saveName);
    event.setPath(savePath);
    event.setFlag(flag);
    event.setUrl(url);
    return event;
  }
}
