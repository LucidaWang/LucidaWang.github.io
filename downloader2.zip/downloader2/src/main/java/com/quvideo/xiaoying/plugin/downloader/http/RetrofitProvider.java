package com.quvideo.xiaoying.plugin.downloader.http;

import com.quvideo.xiaoying.plugin.downloader.constants.HttpConstants;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.quvideo.xiaoying.plugin.downloader.BuildConfig.DEBUG;
import static com.quvideo.xiaoying.plugin.downloader.constants.HttpConstants.DEFAULT_ENDPOINT;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public class RetrofitProvider {
  private RetrofitProvider() {
  }

  private static String endPoint;

  /**
   * 不指定endPoint
   *
   * @return Retrofit
   */
  public static Retrofit getInstance() {
    return getInstance(DEFAULT_ENDPOINT);
  }

  /**
   * 指定endpoint
   *
   * @param endpoint endPoint
   * @return Retrofit
   */
  public static Retrofit getInstance(String endpoint) {
    endPoint = endpoint;
    return SingletonHolder.INSTANCE;
  }

  private static class SingletonHolder {
    private static final Retrofit INSTANCE = create();

    private static Retrofit create() {
      OkHttpClient.Builder builder = new OkHttpClient().newBuilder();

      builder.readTimeout(HttpConstants.TimeOut.READ, TimeUnit.SECONDS);
      builder.connectTimeout(HttpConstants.TimeOut.CONNECTION, TimeUnit.SECONDS);

      if (DEBUG) {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        builder.addInterceptor(interceptor);
      }

      return new Retrofit.Builder().baseUrl(endPoint)
          .client(builder.addNetworkInterceptor(new Interceptor() {
            @Override public Response intercept(Chain chain) throws IOException {
              Request request = chain.request();
              Response response = chain.proceed(request);
              return response.newBuilder().build();
            }
          }).build())
          .addConverterFactory(GsonConverterFactory.create())
          .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
          .build();
    }
  }
}
