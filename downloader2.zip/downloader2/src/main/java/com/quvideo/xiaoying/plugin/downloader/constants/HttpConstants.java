package com.quvideo.xiaoying.plugin.downloader.constants;

/**
 * Created by Administrator on 2017/10/16.
 *
 * @author luc
 */

public class HttpConstants {
  public static String DEFAULT_ENDPOINT = "http://www.xiaoying.tv/api/";

  public static final class ApiParam {
    public static final String TEST_RANGE_SUPPORT = "bytes=0-";
  }

  public static final class Header {
    public static final String RANGE = "Range";
    public static final String IF_MODIFIED_SINCE = "If-Modified-Since";
  }

  public static final class ResponseCode {
    public static final int _200 = 200;
    public static final int _206 = 206;
    public static final int _304 = 304;
  }

  public static final class TimeOut {
    public static final int READ = 10;
    public static final int CONNECTION = 10;
  }
}
