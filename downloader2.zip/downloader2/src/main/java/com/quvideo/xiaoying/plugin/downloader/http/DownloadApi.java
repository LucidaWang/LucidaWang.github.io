package com.quvideo.xiaoying.plugin.downloader.http;

import com.quvideo.xiaoying.plugin.downloader.constants.HttpConstants;
import io.reactivex.Flowable;
import io.reactivex.Observable;
import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.http.GET;
import retrofit2.http.HEAD;
import retrofit2.http.Header;
import retrofit2.http.Streaming;
import retrofit2.http.Url;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public interface DownloadApi {

  @GET @Streaming Flowable<Response<ResponseBody>> download(
      @Header(HttpConstants.Header.RANGE) String range, @Url String url);

  @HEAD Observable<Response<Void>> check(@Url String url);

  @GET Observable<Response<Void>> checkByGet(@Url String url);

  @HEAD Observable<Response<Void>> checkRangeByHead(@Header(HttpConstants.Header.RANGE) String range,
      @Url String url);

  @HEAD Observable<Response<Void>> checkFileByHead(
      @Header(HttpConstants.Header.IF_MODIFIED_SINCE) String lastModify, @Url String url);
}
