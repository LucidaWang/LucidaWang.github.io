package com.quvideo.xiaoying.plugin.downloader.constants;

/**
 * Created by Administrator on 2017/10/16.
 *
 * @author luc
 */

public class FileConstants {
  public static final String TMP_SUFFIX = ".tmp"; //temp file for bytes data
  public static final String LMF_SUFFIX = ".lmf"; //last modify file
  public static final String CACHE = ".cache"; //cache directory
  public static final String DOWNLOAD_SHORT_SUFFIX = ".dst"; //download temp file
}
