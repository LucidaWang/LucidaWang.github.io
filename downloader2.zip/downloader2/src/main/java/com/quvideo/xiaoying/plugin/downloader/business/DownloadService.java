package com.quvideo.xiaoying.plugin.downloader.business;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants;
import com.quvideo.xiaoying.plugin.downloader.constants.LogConstants;
import com.quvideo.xiaoying.plugin.downloader.dao.DBHelper;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadEvent;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadMission;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadRecord;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadStatus;
import com.quvideo.xiaoying.plugin.downloader.entity.SingleMission;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.schedulers.Schedulers;
import java.io.File;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;

import static com.quvideo.xiaoying.plugin.downloader.business.DownloadEventFactory.createEvent;
import static com.quvideo.xiaoying.plugin.downloader.business.DownloadEventFactory.normal;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.WAITING_FOR_MISSION_COME;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.deleteFiles;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.getCacheFile;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.getDownloadFile;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.getFiles;
import static com.quvideo.xiaoying.plugin.downloader.utils.LogUtils.log;
import static com.quvideo.xiaoying.plugin.downloader.utils.RxUtils.createProcessor;
import static com.quvideo.xiaoying.plugin.downloader.utils.RxUtils.dispose;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public class DownloadService extends Service {

  private DownloadBinder mBinder;

  private Semaphore semaphore;
  private BlockingQueue<DownloadMission> downloadQueue;
  private Map<String, DownloadMission> missionMap;
  private Map<String, FlowableProcessor<DownloadEvent>> processorMap;

  private Disposable disposable;
  private DBHelper dBHelper;

  @Override public void onCreate() {
    super.onCreate();
    mBinder = new DownloadBinder();
    downloadQueue = new LinkedBlockingQueue<>();
    processorMap = new ConcurrentHashMap<>();
    missionMap = new ConcurrentHashMap<>();

    dBHelper = DBHelper.getInstance(getApplicationContext());
  }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    log("start Download Service");
    dBHelper.repairErrorFlag();
    if (intent != null) {
      int maxDownloadNumber = intent.getIntExtra(DownloadConstants.IntentKey.MAX_DOWNLOAD_NUMBER,
          DownloadConstants.IntentDefaultValue.MAX_DOWNLOAD_NUMBER);
      semaphore = new Semaphore(maxDownloadNumber);
    }
    return super.onStartCommand(intent, flags, startId);
  }

  @Override public void onDestroy() {
    super.onDestroy();
    log("destroy Download Service");
    destroy();
    dBHelper.closeDataBase();
  }

  @Override public IBinder onBind(Intent intent) {
    log("bind Download Service");
    startDispatch();
    return mBinder;
  }

  /**
   * Receive the url download event.
   * Every event has {@link DownloadStatus}, you can get it and display it on the interface.
   *
   * @param url url
   * @return DownloadEvent
   */
  public FlowableProcessor<DownloadEvent> receiveDownloadEvent(String url) {
    FlowableProcessor<DownloadEvent> processor = createProcessor(url, processorMap);
    DownloadMission mission = missionMap.get(url);
    if (mission == null) {  //Not yet add this url mission.
      DownloadRecord record = dBHelper.readSingleRecord(url);
      if (record == null) {
        processor.onNext(normal(url, null));
      } else {
        File file = getDownloadFile(getFiles(record.getSaveName(), record.getSavePath()));
        if (file.exists()) {
          processor.onNext(createEvent(record.getFlag(), url, record.getStatus()));
        } else {
          processor.onNext(normal(url, null));
        }
      }
    }
    return processor;
  }

  /**
   * Add this mission into download queue.
   *
   * @param mission mission
   * @throws InterruptedException Blocking queue
   */
  public void addDownloadMission(DownloadMission mission) throws InterruptedException {
    mission.init(missionMap, processorMap);
    mission.insertOrUpdate(dBHelper);
    mission.sendWaitingEvent(dBHelper);

    downloadQueue.put(mission);
  }

  /**
   * Pause download.
   * <p>
   * Pause a url or all tasks belonging to missionId.
   *
   * @param url url or missionId
   */
  public void pauseDownload(String url) {
    DownloadMission mission = missionMap.get(url);
    if (mission != null && mission instanceof SingleMission) {
      mission.pause(dBHelper);
    }
  }

  /**
   * Delete download.
   * <p>
   * Delete a url or all tasks belonging to missionId.
   *
   * @param url url or missionId
   * @param deleteFile whether delete file
   */
  public void deleteDownload(String url, boolean deleteFile) {
    DownloadMission mission = missionMap.get(url);
    if (mission != null && mission instanceof SingleMission) {
      mission.delete(dBHelper, deleteFile);
      missionMap.remove(url);
    } else {
      createProcessor(url, processorMap).onNext(normal(url, null));
      DownloadRecord record = dBHelper.readSingleRecord(url);
      if (record != null) {
        File[] files;
        if (deleteFile) {
          files = getFiles(record.getSaveName(), record.getSavePath());
        } else {
          files = getCacheFile(record.getSaveName(), record.getSavePath());
        }
        deleteFiles(files);
      }

      dBHelper.deleteRecord(url);
    }
  }

  /**
   * Start all mission. Not include MultiMission.
   *
   * @throws InterruptedException interrupt
   */
  public void startAll() throws InterruptedException {
    for (DownloadMission each : missionMap.values()) {
      if (each.isCompleted()) {
        continue;
      }

      if (each instanceof SingleMission) {
        addDownloadMission(new SingleMission((SingleMission) each));
      }
    }
  }

  /**
   * Pause all mission.Not include MultiMission.
   */
  public void pauseAll() {
    for (DownloadMission each : missionMap.values()) {
      if (each instanceof SingleMission) {
        each.pause(dBHelper);
      }
    }
    downloadQueue.clear();
  }

  /**
   * start dispatch download queue.
   */
  private void startDispatch() {
    disposable = Observable.create(new ObservableOnSubscribe<DownloadMission>() {
      @Override public void subscribe(ObservableEmitter<DownloadMission> emitter) throws Exception {
        DownloadMission mission;
        while (!emitter.isDisposed()) {
          try {
            log(WAITING_FOR_MISSION_COME);
            mission = downloadQueue.take();
            log(LogConstants.MISSION_COMING);
          } catch (InterruptedException e) {
            log("Interrupt blocking queue.");
            continue;
          }
          emitter.onNext(mission);
        }
        emitter.onComplete();
      }
    }).subscribeOn(Schedulers.io()).subscribe(new Consumer<DownloadMission>() {
      @Override public void accept(DownloadMission mission) throws Exception {
        mission.start(semaphore);
      }
    }, new Consumer<Throwable>() {
      @Override public void accept(Throwable throwable) throws Exception {
        log(throwable);
      }
    });
  }

  /**
   * Call when service is onDestroy.
   */
  private void destroy() {
    dispose(disposable);
    for (DownloadMission each : missionMap.values()) {
      each.pause(dBHelper);
    }
    downloadQueue.clear();
  }

  public class DownloadBinder extends Binder {
    public DownloadService getService() {
      return DownloadService.this;
    }
  }
}
