package com.quvideo.xiaoying.plugin.downloader.utils;

import com.quvideo.xiaoying.plugin.downloader.entity.DownloadEvent;
import io.reactivex.Flowable;
import io.reactivex.FlowableTransformer;
import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.ObservableTransformer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.BiPredicate;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.processors.PublishProcessor;
import java.net.ConnectException;
import java.net.ProtocolException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Map;
import org.reactivestreams.Publisher;
import retrofit2.HttpException;

import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.RETRY_HINT;
import static com.quvideo.xiaoying.plugin.downloader.utils.LogUtils.log;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */

public class RxUtils {
  public static FlowableProcessor<DownloadEvent> createProcessor(String missionId,
      Map<String, FlowableProcessor<DownloadEvent>> processorMap) {

    if (processorMap.get(missionId) == null) {
      FlowableProcessor<DownloadEvent> processor =
          PublishProcessor.<DownloadEvent>create().toSerialized();
      processorMap.put(missionId, processor);
    }
    return processorMap.get(missionId);
  }

  public static <U> ObservableTransformer<U, U> retry(final String hint, final int retryCount) {
    return new ObservableTransformer<U, U>() {
      @Override public ObservableSource<U> apply(Observable<U> upstream) {
        return upstream.retry(new BiPredicate<Integer, Throwable>() {
          @Override public boolean test(Integer integer, Throwable throwable) throws Exception {
            return retry(hint, retryCount, integer, throwable);
          }
        });
      }
    };
  }

  public static <U> FlowableTransformer<U, U> retry2(final String hint, final int retryCount) {
    return new FlowableTransformer<U, U>() {
      @Override public Publisher<U> apply(Flowable<U> upstream) {
        return upstream.retry(new BiPredicate<Integer, Throwable>() {
          @Override public boolean test(Integer integer, Throwable throwable) throws Exception {
            return retry(hint, retryCount, integer, throwable);
          }
        });
      }
    };
  }

  public static Boolean retry(String hint, int maxRetryCount, Integer integer,
      Throwable throwable) {
    if (throwable instanceof ProtocolException) {
      if (integer < maxRetryCount + 1) {
        log(RETRY_HINT, hint, "ProtocolException", integer);
        return true;
      }
      return false;
    } else if (throwable instanceof UnknownHostException) {
      if (integer < maxRetryCount + 1) {
        log(RETRY_HINT, hint, "UnknownHostException", integer);
        return true;
      }
      return false;
    } else if (throwable instanceof HttpException) {
      if (integer < maxRetryCount + 1) {
        log(RETRY_HINT, hint, "HttpException", integer);
        return true;
      }
      return false;
    } else if (throwable instanceof SocketTimeoutException) {
      if (integer < maxRetryCount + 1) {
        log(RETRY_HINT, hint, "SocketTimeoutException", integer);
        return true;
      }
      return false;
    } else if (throwable instanceof ConnectException) {
      if (integer < maxRetryCount + 1) {
        log(RETRY_HINT, hint, "ConnectException", integer);
        return true;
      }
      return false;
    } else if (throwable instanceof SocketException) {
      if (integer < maxRetryCount + 1) {
        log(RETRY_HINT, hint, "SocketException", integer);
        return true;
      }
      return false;
    } else {
      return false;
    }
  }

  public static void dispose(Disposable disposable) {
    if (disposable != null && !disposable.isDisposed()) {
      disposable.dispose();
    }
  }
}
