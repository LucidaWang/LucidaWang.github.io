package com.quvideo.xiaoying.plugin.downloader;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.quvideo.xiaoying.plugin.downloader.business.DownloadHelper;
import com.quvideo.xiaoying.plugin.downloader.business.DownloadService;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadEvent;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadInfo;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadRecord;
import com.quvideo.xiaoying.plugin.downloader.entity.SingleMission;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.ObservableSource;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.plugins.RxJavaPlugins;
import io.reactivex.schedulers.Schedulers;
import java.io.File;
import java.io.InterruptedIOException;
import java.net.SocketException;
import java.util.List;
import java.util.concurrent.Semaphore;
import retrofit2.Retrofit;

import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.IntentKey.MAX_DOWNLOAD_NUMBER;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.getDownloadFile;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.getFiles;
import static com.quvideo.xiaoying.plugin.downloader.utils.LogUtils.log;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public class RxDownloader {
  private static final Object object = new Object();
  @SuppressLint("StaticFieldLeak") private volatile static RxDownloader instance;
  private volatile static boolean bound = false;

  static {
    RxJavaPlugins.setErrorHandler(new Consumer<Throwable>() {
      @Override public void accept(Throwable throwable) throws Exception {
        if (throwable instanceof InterruptedException) {
          log("Thread interrupted");
        } else if (throwable instanceof InterruptedIOException) {
          log("Io interrupted");
        } else if (throwable instanceof SocketException) {
          log("Socket error");
        }
      }
    });
  }

  private int maxDownloadNumber = 5;

  private Context context;
  private Semaphore semaphore;

  private DownloadService downloadService;
  private DownloadHelper downloadHelper;

  private RxDownloader(Context context) {
    this.context = context.getApplicationContext();
    downloadHelper = new DownloadHelper(context);
    semaphore = new Semaphore(1);
  }

  /**
   * 获取实例
   *
   * @param context context
   * @return RxDownload
   */
  public static RxDownloader getInstance(Context context) {
    if (instance == null) {
      synchronized (RxDownloader.class) {
        if (instance == null) {
          instance = new RxDownloader(context);
        }
      }
    }
    return instance;
  }

  /**
   * 通过url获取已经完成的下载文件，如果数据库中对应记录丢失会返回null
   * File {DownloadFile}
   *
   * @param url url
   * @return File
   */
  public File getRealFile(String url) {
    return getDownloadFile(downloadHelper.getFiles(url));
  }

  /**
   * 通过名称和路径获取已经完成的下载文件
   *
   * @param saveName saveName 保存名称
   * @param savePath savePath 保存路径
   * @return File
   */
  public File getRealFile(String saveName, String savePath) {
    return getDownloadFile(getFiles(saveName, savePath));
  }

  /**
   * set default save path.
   *
   * @param savePath default save path.
   * @return instance.
   */
  public RxDownloader defaultSavePath(String savePath) {
    downloadHelper.setDefaultSavePath(savePath);
    return this;
  }

  /**
   * 可自定义 retrofit client
   *
   * @param retrofit retrofit client
   * @return instance.
   */
  public RxDownloader retrofit(Retrofit retrofit) {
    downloadHelper.setRetrofit(retrofit);
    return this;
  }

  /**
   * 下载文件 允许最大线程数
   *
   * @param max max threads 最大线程数
   * @return instance
   */
  public RxDownloader maxThread(int max) {
    downloadHelper.setMaxThreads(max);
    return this;
  }

  /**
   * 下载失败最多重试次数
   *
   * @param max max retry count
   * @return instance
   */
  public RxDownloader maxRetryCount(int max) {
    downloadHelper.setMaxRetryCount(max);
    return this;
  }

  /**
   * 最多同时下载数目
   *
   * @param max max download number
   * @return instance
   */
  public RxDownloader maxDownloadNumber(int max) {
    this.maxDownloadNumber = max;
    return this;
  }

  /**
   * 设置是否支持断点续传
   *
   * @param support 是否支持断点续传
   * @return instance
   */
  public RxDownloader supportRangeDownload(boolean support) {
    this.downloadHelper.setSupportRangeDownload(support);
    return this;
  }

  /**
   * 通过url 获取对应下载文件的进度监听
   *
   * @param url url
   * @return DownloadEvent
   */
  public Observable<DownloadEvent> receiveDownloadStatus(final String url) {
    return createGeneralObservable(null).flatMap(
        new Function<Object, ObservableSource<DownloadEvent>>() {
          @Override public ObservableSource<DownloadEvent> apply(Object o) throws Exception {
            return downloadService.receiveDownloadEvent(url).toObservable();
          }
        }).observeOn(AndroidSchedulers.mainThread());
  }

  /**
   * 从数据库中读取所有的下载记录
   *
   * @return Observable<List<DownloadRecord>>
   */
  public Observable<List<DownloadRecord>> getTotalDownloadRecords() {
    return downloadHelper.readAllRecords();
  }

  /**
   * 通过url获取对应的下载记录
   *
   * @param url download url
   * @return Observable<DownloadStatus>
   */
  public Observable<DownloadRecord> getDownloadRecord(String url) {
    return downloadHelper.readRecord(url);
  }

  /**
   * 暂停下载
   * <p>
   * Pause a download.
   *
   * @param url url
   */
  public Observable<?> pause(final String url) {
    return createGeneralObservable(new GeneralObservableCallback() {
      @Override public void call() {
        downloadService.pauseDownload(url);
      }
    }).observeOn(AndroidSchedulers.mainThread());
  }

  /**
   * 删除下载
   *
   * @param url url
   */
  public Observable<?> delete(final String url) {
    return createGeneralObservable(new GeneralObservableCallback() {
      @Override public void call() {
        downloadService.deleteDownload(url, true);
      }
    }).observeOn(AndroidSchedulers.mainThread());
  }

  /**
   * 开始所有的已暂停的下载
   *
   * @return Observable
   */
  public Observable<?> startAll() {
    return createGeneralObservable(new GeneralObservableCallback() {
      @Override public void call() throws InterruptedException {
        downloadService.startAll();
      }
    }).observeOn(AndroidSchedulers.mainThread());
  }

  /**
   * 暂停所有的下载
   *
   * @return Observable
   */
  public Observable<?> pauseAll() {
    return createGeneralObservable(new GeneralObservableCallback() {
      @Override public void call() {
        downloadService.pauseAll();
      }
    }).observeOn(AndroidSchedulers.mainThread());
  }

  /**
   * 返回指定下载文件大小字节数
   */
  public Observable<Long> getDownloadSize(String url) {
    return downloadHelper.getDownloadFileSize(url);
  }

  /**
   * 下载文件
   *
   * @param url url
   * @return Observable<DownloadStatus>
   */
  public Observable<?> download(String url) {
    return download(url, "");
  }

  /**
   * 下载文件
   *
   * @param url url
   * @param savePath savePath
   * @return Observable<DownloadStatus>
   */
  public Observable<?> download(String url, String savePath) {
    return download(url, null, savePath);
  }

  /**
   * 下载文件
   *
   * @param url url
   * @param saveName saveName
   * @param savePath savePath
   * @return Observable<DownloadStatus>
   */
  public Observable<?> download(String url, String saveName, String savePath) {
    return download(
        new DownloadInfo.Builder(url).setSaveName(saveName).setSavePath(savePath).build());
  }

  /**
   * 下载文件
   *
   * @param info download info
   * @return Observable<DownloadStatus>
   */
  public Observable<?> download(final DownloadInfo info) {
    return createGeneralObservable(new GeneralObservableCallback() {
      @Override public void call() throws InterruptedException {
        downloadService.addDownloadMission(
            new SingleMission(downloadService, downloadHelper, info));
      }
    }).observeOn(AndroidSchedulers.mainThread());
  }

  /**
   * 文件完成下载退出界面时需要注销对应的 observer
   *
   * @param disposables disposables
   */
  public void dispose(Disposable... disposables) {
    if (disposables == null || disposables.length == 0) {
      return;
    }
    for (Disposable disposable : disposables) {
      if (disposable != null && !disposable.isDisposed()) {
        disposable.dispose();
      }
    }
  }

  /**
   * 生成通用的 observable
   *
   * @param callback Called when observable created.
   * @return Observable
   */
  private Observable<?> createGeneralObservable(final GeneralObservableCallback callback) {
    return Observable.create(new ObservableOnSubscribe<Object>() {
      @Override public void subscribe(final ObservableEmitter<Object> emitter) throws Exception {
        if (!bound) {
          semaphore.acquire();
          if (!bound) {
            startBindServiceAndDo(new ServiceConnectedCallback() {
              @Override public void call() {
                doCall(callback, emitter);
                semaphore.release();
              }
            });
          } else {
            doCall(callback, emitter);
            semaphore.release();
          }
        } else {
          doCall(callback, emitter);
        }
      }
    }).subscribeOn(Schedulers.io());
  }

  private void doCall(GeneralObservableCallback callback, ObservableEmitter<Object> emitter) {
    if (callback != null) {
      try {
        callback.call();
      } catch (Exception e) {
        emitter.onError(e);
      }
    }
    emitter.onNext(object);
    emitter.onComplete();
  }

  /**
   * 启动下载 service
   *
   * @param callback Called when service connected.
   */
  private void startBindServiceAndDo(final ServiceConnectedCallback callback) {
    Intent intent = new Intent(context, DownloadService.class);
    intent.putExtra(MAX_DOWNLOAD_NUMBER, maxDownloadNumber);
    context.startService(intent);
    context.bindService(intent, new ServiceConnection() {
      @Override public void onServiceConnected(ComponentName name, IBinder binder) {
        DownloadService.DownloadBinder downloadBinder = (DownloadService.DownloadBinder) binder;
        downloadService = downloadBinder.getService();
        context.unbindService(this);
        bound = true;
        callback.call();
      }

      @Override public void onServiceDisconnected(ComponentName name) {
        //注意!!这个方法只会在系统杀掉Service时才会调用!!
        bound = false;
      }
    }, Context.BIND_AUTO_CREATE);
  }

  private interface GeneralObservableCallback {
    void call() throws Exception;
  }

  private interface ServiceConnectedCallback {
    void call();
  }
}
