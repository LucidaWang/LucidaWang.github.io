package com.quvideo.xiaoying.plugin.downloader.utils;

import android.text.TextUtils;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.internal.http.HttpHeaders;
import retrofit2.Response;

import static com.quvideo.xiaoying.plugin.downloader.utils.LogUtils.log;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */

public class HttpUtils {

  public static String fileName(String url, Response<?> response) {
    String fileName = contentDisposition(response);
    if (TextUtils.isEmpty(fileName)) {
      fileName = url.substring(url.lastIndexOf('/') + 1);
    }
    if (fileName.startsWith("\"")) {
      fileName = fileName.substring(1);
    }
    if (fileName.endsWith("\"")) {
      fileName = fileName.substring(0, fileName.length() - 1);
    }
    return fileName;
  }

  public static String contentDisposition(Response<?> response) {
    String disposition = response.headers().get("Content-Disposition");
    if (TextUtils.isEmpty(disposition)) {
      return "";
    }
    Matcher m = Pattern.compile(".*filename=(.*)").matcher(disposition.toLowerCase());
    if (m.find()) {
      return m.group(1);
    } else {
      return "";
    }
  }

  public static boolean isChunked(Response<?> response) {
    return "chunked".equals(transferEncoding(response));
  }

  public static boolean notSupportRange(Response<?> response) {
    return (TextUtils.isEmpty(contentRange(response)) && !TextUtils.equals(acceptRanges(response),
        "bytes")) || contentLength(response) == -1 || isChunked(response);
  }

  public static long contentLength(Response<?> response) {
    return HttpHeaders.contentLength(response.headers());
  }

  public static String lastModify(Response<?> response) {
    return response.headers().get("Last-Modified");
  }

  private static String transferEncoding(Response<?> response) {
    return response.headers().get("Transfer-Encoding");
  }

  private static String contentRange(Response<?> response) {
    return response.headers().get("Content-Range");
  }

  private static String acceptRanges(Response<?> response) {
    return response.headers().get("Accept-Ranges");
  }
}
