package com.quvideo.xiaoying.plugin.downloader.entity;

import com.quvideo.xiaoying.plugin.downloader.business.DownloadHelper;
import com.quvideo.xiaoying.plugin.downloader.business.DownloadService;
import com.quvideo.xiaoying.plugin.downloader.constants.LogConstants;
import com.quvideo.xiaoying.plugin.downloader.dao.DBHelper;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.processors.FlowableProcessor;
import io.reactivex.schedulers.Schedulers;
import java.io.File;
import java.util.Map;
import java.util.concurrent.Semaphore;

import static com.quvideo.xiaoying.plugin.downloader.business.DownloadEventFactory.completed;
import static com.quvideo.xiaoying.plugin.downloader.business.DownloadEventFactory.failed;
import static com.quvideo.xiaoying.plugin.downloader.business.DownloadEventFactory.normal;
import static com.quvideo.xiaoying.plugin.downloader.business.DownloadEventFactory.paused;
import static com.quvideo.xiaoying.plugin.downloader.business.DownloadEventFactory.started;
import static com.quvideo.xiaoying.plugin.downloader.business.DownloadEventFactory.waiting;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.WAITING;
import static com.quvideo.xiaoying.plugin.downloader.utils.CharacterUtils.formatStr;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.deleteFiles;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.getCacheFile;
import static com.quvideo.xiaoying.plugin.downloader.utils.FileUtils.getFiles;
import static com.quvideo.xiaoying.plugin.downloader.utils.LogUtils.log;
import static com.quvideo.xiaoying.plugin.downloader.utils.RxUtils.createProcessor;
import static com.quvideo.xiaoying.plugin.downloader.utils.RxUtils.dispose;

/**
 * Created by Administrator on 2017/10/10.
 *
 * @author luc
 */
public class SingleMission extends DownloadMission {
  private DownloadStatus status;
  private Disposable disposable;
  private DownloadInfo bean;

  public SingleMission(SingleMission other) {
    this(other.downloadService, other.downloadHelper, other.getBean());
  }

  public SingleMission(DownloadService downloadService, DownloadHelper downloadHelper,
      DownloadInfo bean) {
    super(downloadService, downloadHelper);
    this.bean = bean;
  }

  @Override public String getUrl() {
    return bean.getUrl();
  }

  @Override public void init(Map<String, DownloadMission> missionMap,
      Map<String, FlowableProcessor<DownloadEvent>> processorMap) {
    DownloadMission mission = missionMap.get(getUrl());
    if (mission == null) {
      missionMap.put(getUrl(), this);
    } else {
      if (mission.isCanceled()) {
        missionMap.put(getUrl(), this);
      } else {
        throw new IllegalArgumentException(formatStr(LogConstants.DOWNLOAD_URL_EXISTS, getUrl()));
      }
    }
    this.processor = createProcessor(getUrl(), processorMap);
  }

  @Override public void insertOrUpdate(DBHelper dBHelper) {
    if (dBHelper.recordNotExists(getUrl())) {
      dBHelper.insertRecord(bean, WAITING);
    } else {
      dBHelper.updateRecord(getUrl(), WAITING);
    }
  }

  @Override public void sendWaitingEvent(DBHelper dBHelper) {
    processor.onNext(waiting(getUrl(), dBHelper.readStatus(getUrl())));
  }

  @Override public void start(final Semaphore semaphore) throws InterruptedException {
    if (isCanceled()) {
      return;
    }

    semaphore.acquire();

    if (isCanceled()) {
      semaphore.release();
      return;
    }

    disposable = downloadHelper.downloadDispatcher(bean)
        .subscribeOn(Schedulers.io())
        .doFinally(new Action() {
          @Override public void run() throws Exception {
            log("finally and release...");
            setCanceled(true);
            semaphore.release();
          }
        })
        .subscribe(new Consumer<DownloadStatus>() {
          @Override public void accept(DownloadStatus value) throws Exception {
            status = value;
            processor.onNext(started(getUrl(), value));
          }
        }, new Consumer<Throwable>() {
          @Override public void accept(Throwable throwable) throws Exception {
            processor.onNext(failed(getUrl(), status, throwable));
          }
        }, new Action() {
          @Override public void run() throws Exception {
            downloadService.deleteDownload(getUrl(), false);
            processor.onNext(completed(getUrl(), bean.getSaveName(), bean.getSavePath(), status));
            setCompleted(true);
          }
        });
  }

  @Override public void pause(DBHelper dBHelper) {
    dispose(disposable);
    setCanceled(true);
    if (processor != null && !isCompleted()) {
      processor.onNext(paused(getUrl(), dBHelper.readStatus(getUrl())));
    }
  }

  @Override public void delete(DBHelper dBHelper, boolean deleteFile) {
    if (deleteFile) {
      pause(dBHelper);
      if (processor != null) {
        processor.onNext(normal(getUrl(), null));
      }
    }

    DownloadRecord record = dBHelper.readSingleRecord(getUrl());
    if (record != null) {
      File[] files;
      if (deleteFile) {
        files = getFiles(record.getSaveName(), record.getSavePath());
      } else {
        files = getCacheFile(record.getSaveName(), record.getSavePath());
      }
      deleteFiles(files);
    }

    dBHelper.deleteRecord(getUrl());
  }

  private DownloadInfo getBean() {
    return bean;
  }
}