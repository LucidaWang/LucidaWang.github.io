package com.quvideo.xiaoying.plugin.downloader.utils;

import android.util.Log;

import static android.text.TextUtils.isEmpty;
import static com.quvideo.xiaoying.plugin.downloader.constants.LogConstants.TAG;
import static java.lang.String.format;
import static java.util.Locale.getDefault;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */

public class LogUtils {

  private static boolean DEBUG = false;

  public static void setDebug(boolean flag) {
    DEBUG = flag;
  }

  public static void log(String message) {
    if (isEmpty(message)) return;
    if (DEBUG) {
      Log.i(TAG, message);
    }
  }

  public static void log(String message, Object... args) {
    log(format(getDefault(), message, args));
  }

  public static void log(Throwable throwable) {
    Log.w(TAG, throwable);
  }
}
