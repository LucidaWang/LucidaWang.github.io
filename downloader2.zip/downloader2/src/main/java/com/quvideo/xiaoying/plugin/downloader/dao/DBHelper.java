package com.quvideo.xiaoying.plugin.downloader.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadInfo;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadRecord;
import com.quvideo.xiaoying.plugin.downloader.entity.DownloadStatus;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import java.util.ArrayList;
import java.util.List;

import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_DATE;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_DOWNLOAD_FLAG;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_DOWNLOAD_SIZE;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_ID;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_IS_CHUNKED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_SAVE_NAME;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_SAVE_PATH;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_TOTAL_SIZE;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.COLUMN_URL;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.SQL_CREATE;
import static com.quvideo.xiaoying.plugin.downloader.constants.DBConstants.RecordTable.TABLE_NAME;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.PAUSED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.STARTED;
import static com.quvideo.xiaoying.plugin.downloader.constants.DownloadConstants.Flag.WAITING;
import static com.quvideo.xiaoying.plugin.downloader.dao.DBOptions.insert;
import static com.quvideo.xiaoying.plugin.downloader.dao.DBOptions.read;
import static com.quvideo.xiaoying.plugin.downloader.dao.DBOptions.update;
import static com.quvideo.xiaoying.plugin.downloader.utils.LogUtils.log;

/**
 * Created by Administrator on 2017/10/4.
 *
 * @author luc
 */
public class DBHelper {
  private volatile static DBHelper singleton;
  private final Object databaseLock = new Object();
  private DbOpenHelper mDbOpenHelper;
  private volatile SQLiteDatabase readableDatabase;
  private volatile SQLiteDatabase writableDatabase;

  private DBHelper(Context context) {
    mDbOpenHelper = new DbOpenHelper(context);
  }

  public static DBHelper getInstance(Context context) {
    if (singleton == null) {
      synchronized (DBHelper.class) {
        if (singleton == null) {
          singleton = new DBHelper(context);
        }
      }
    }
    return singleton;
  }

  /**
   * Judge the url's record exists.
   *
   * @param url url
   * @return true if not exists
   */
  public boolean recordNotExists(String url) {
    Cursor cursor = null;
    try {
      cursor =
          getReadableDatabase().query(TABLE_NAME, new String[] { COLUMN_ID }, COLUMN_URL + "=?",
              new String[] { url }, null, null, null);
      cursor.moveToFirst();
      return cursor.getCount() == 0;
    } finally {
      if (cursor != null) {
        cursor.close();
      }
    }
  }

  public long insertRecord(DownloadInfo downloadBean, int flag) {
    return getWritableDatabase().insert(TABLE_NAME, null, insert(downloadBean, flag));
  }

  public long updateStatus(String url, DownloadStatus status) {
    return getWritableDatabase().update(TABLE_NAME, update(status), COLUMN_URL + "=?",
        new String[] { url });
  }

  public long updateRecord(String url, int flag) {
    return getWritableDatabase().update(TABLE_NAME, update(flag), COLUMN_URL + "=?",
        new String[] { url });
  }

  public long updateRecord(String url, String saveName, String savePath, int flag) {
    return getWritableDatabase().update(TABLE_NAME, update(saveName, savePath, flag),
        COLUMN_URL + "=?", new String[] { url });
  }

  public int deleteRecord(String url) {
    return getWritableDatabase().delete(TABLE_NAME, COLUMN_URL + "=?", new String[] { url });
  }

  public long repairErrorFlag() {
    return getWritableDatabase().update(TABLE_NAME, update(PAUSED),
        COLUMN_DOWNLOAD_FLAG + "=? or " + COLUMN_DOWNLOAD_FLAG + "=?",
        new String[] { WAITING + "", STARTED + "" });
  }

  /**
   * Read single Record.
   *
   * @param url url
   * @return Record
   */
  public DownloadRecord readSingleRecord(String url) {
    Cursor cursor = null;
    try {
      cursor = getReadableDatabase().query(TABLE_NAME, new String[] {
          COLUMN_ID, COLUMN_URL, COLUMN_SAVE_NAME, COLUMN_SAVE_PATH, COLUMN_DOWNLOAD_SIZE,
          COLUMN_TOTAL_SIZE, COLUMN_IS_CHUNKED, COLUMN_DOWNLOAD_FLAG, COLUMN_DATE
      }, COLUMN_URL + "=?", new String[] { url }, null, null, null);
      cursor.moveToFirst();
      if (cursor.getCount() == 0) {
        return null;
      } else {
        return read(cursor);
      }
    } finally {
      if (cursor != null) {
        cursor.close();
      }
    }
  }

  /**
   * Read the url's download status.
   *
   * @param url url
   * @return download status
   */
  public DownloadStatus readStatus(String url) {
    Cursor cursor = null;
    try {
      cursor = getReadableDatabase().query(TABLE_NAME,
          new String[] { COLUMN_DOWNLOAD_SIZE, COLUMN_TOTAL_SIZE, COLUMN_IS_CHUNKED },
          COLUMN_URL + "=?", new String[] { url }, null, null, null);
      cursor.moveToFirst();
      if (cursor.getCount() == 0) {
        return new DownloadStatus();
      } else {
        return DBOptions.readStatus(cursor);
      }
    } finally {
      if (cursor != null) {
        cursor.close();
      }
    }
  }

  /**
   * Read all records from database.
   *
   * @return All records.
   */
  public Observable<List<DownloadRecord>> readAllRecords() {
    return Observable.create(new ObservableOnSubscribe<List<DownloadRecord>>() {
      @Override public void subscribe(ObservableEmitter<List<DownloadRecord>> emitter)
          throws Exception {
        Cursor cursor = null;
        try {
          cursor = getReadableDatabase().query(TABLE_NAME, new String[] {
              COLUMN_ID, COLUMN_URL, COLUMN_SAVE_NAME, COLUMN_SAVE_PATH, COLUMN_DOWNLOAD_SIZE,
              COLUMN_TOTAL_SIZE, COLUMN_IS_CHUNKED, COLUMN_DOWNLOAD_FLAG, COLUMN_DATE
          }, null, null, null, null, null);
          List<DownloadRecord> result = new ArrayList<>();
          cursor.moveToFirst();
          if (cursor.getCount() > 0) {
            do {
              result.add(read(cursor));
            } while (cursor.moveToNext());
          }
          emitter.onNext(result);
          emitter.onComplete();
        } finally {
          if (cursor != null) {
            cursor.close();
          }
        }
      }
    }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
  }

  /**
   * Read the url's record.
   * <p>
   * If record not exists, return an empty record.
   *
   * @param url url
   * @return record
   */
  public Observable<DownloadRecord> readRecord(final String url) {
    return Observable.create(new ObservableOnSubscribe<DownloadRecord>() {
      @Override public void subscribe(ObservableEmitter<DownloadRecord> emitter) throws Exception {
        Cursor cursor = null;
        try {
          cursor = getReadableDatabase().query(TABLE_NAME, new String[] {
              COLUMN_ID, COLUMN_URL, COLUMN_SAVE_NAME, COLUMN_SAVE_PATH, COLUMN_DOWNLOAD_SIZE,
              COLUMN_TOTAL_SIZE, COLUMN_IS_CHUNKED, COLUMN_DOWNLOAD_FLAG, COLUMN_DATE
          }, COLUMN_URL + "=?", new String[] { url }, null, null, null);
          cursor.moveToFirst();
          if (cursor.getCount() == 0) {
            emitter.onNext(new DownloadRecord());
          } else {
            emitter.onNext(read(cursor));
          }
          emitter.onComplete();
        } finally {
          if (cursor != null) {
            cursor.close();
          }
        }
      }
    }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread());
  }

  public void closeDataBase() {
    synchronized (databaseLock) {
      readableDatabase = null;
      writableDatabase = null;
      mDbOpenHelper.close();
    }
  }

  private SQLiteDatabase getWritableDatabase() {
    SQLiteDatabase db = writableDatabase;
    if (db == null) {
      synchronized (databaseLock) {
        db = writableDatabase;
        if (db == null) {
          db = writableDatabase = mDbOpenHelper.getWritableDatabase();
        }
      }
    }
    return db;
  }

  private SQLiteDatabase getReadableDatabase() {
    SQLiteDatabase db = readableDatabase;
    if (db == null) {
      synchronized (databaseLock) {
        db = readableDatabase;
        if (db == null) {
          db = readableDatabase = mDbOpenHelper.getReadableDatabase();
        }
      }
    }
    return db;
  }

  private static class DbOpenHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "quvideo_xiaoying_download.db";
    private static final int DATABASE_VERSION = 1;

    DbOpenHelper(Context context) {
      super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
      db.beginTransaction();
      try {
        db.execSQL(SQL_CREATE);
        db.setTransactionSuccessful();
      } catch (Exception e) {
        log(e.getMessage() + "");
      } finally {
        db.endTransaction();
      }
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
  }
}